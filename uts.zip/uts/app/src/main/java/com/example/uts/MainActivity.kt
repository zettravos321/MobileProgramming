package com.example.uts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_budaya.setOnClickListener{
            val btn_budaya = findViewById<Button>(R.id.btn_budaya)
            startActivity(Intent(this@MainActivity, Budaya::class.java))
    }

        btn_perhitungan.setOnClickListener{
            val btn_perhitungan = findViewById<Button>(R.id.btn_perhitungan)
            startActivity(Intent(this@MainActivity, Perhitungan::class.java))
        }

        btn_close.setOnClickListener{
            finishAffinity()
        }
    }



}