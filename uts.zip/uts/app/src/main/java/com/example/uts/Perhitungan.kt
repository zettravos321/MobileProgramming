package com.example.uts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_perhitungan.*

class Perhitungan : AppCompatActivity() {
    private val Logikane=Logika()
    class Logika {
        var result = 0.0

        fun kali(p: Double, l: Double): Double {
            this.result = p * l
            return p * l
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perhitungan)

        val actionBar = supportActionBar

                actionBar!!.title = "PERHITUNGAN"

        actionBar.setDisplayHomeAsUpEnabled(true)
        actionBar.setDisplayHomeAsUpEnabled(true)

        val num1 = editTextNumber1.text
        val num2 = editTextNumber2.text

        btn_kali.setOnClickListener {
            val hasil = Logikane.kali(num1.toString().toDouble(), num2.toString().toDouble())
            val intent = Intent(this, Hasil::class.java)
            intent.putExtra("HASIL", hasil.toString())
            startActivity(intent)
        }

        btn_kembali.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }





    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
    }
