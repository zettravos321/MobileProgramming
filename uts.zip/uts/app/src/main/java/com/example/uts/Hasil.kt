package com.example.uts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_hasil.*

class Hasil : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hasil)

        val actionBar = supportActionBar

        actionBar!!.title = "PERHITUNGAN"

        actionBar.setDisplayHomeAsUpEnabled(true)
        actionBar.setDisplayHomeAsUpEnabled(true)

        var Tampil = intent
        val hasil = Tampil.getStringExtra("HASIL")

        val hasil_akhir = findViewById<TextView>(R.id.txt_hasil)
        hasil_akhir.text = "Hasil : $hasil"


        btn_back.setOnClickListener {
            val intent = Intent(this, Perhitungan::class.java)
            startActivity(intent)
        }

    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}