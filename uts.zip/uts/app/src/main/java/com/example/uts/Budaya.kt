package com.example.uts

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Budaya : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budaya)

        val actionBar = supportActionBar

        actionBar!!.title = "Budaya"

        actionBar.setDisplayHomeAsUpEnabled(true)
        actionBar.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}